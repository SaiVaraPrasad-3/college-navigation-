import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'drawer page/drawer.dart';
import 'package:location/location.dart';
import 'package:flutter/services.dart';

class MapScreen extends StatefulWidget {
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  bool _isAdmin = false;

  Completer<GoogleMapController> mapController = Completer();
  StreamSubscription<Map<String, double>> _locationSubscription;

  Location _location = new Location();

  Map<String, double> _startLocation;
  Map<String, double> _currentLocation;

  bool _permission = false;
  String error;
  bool nullLocation = false;
  bool currentWidget = true;

  @override
  void initState() {
    super.initState();

    getLocation();

    _locationSubscription =
        _location.onLocationChanged().listen((Map<String, double> result) {
      setState(() {
        _currentLocation = result;
      });
    });

    // setState(() {
    //   _currentLocation == null ? nullLocation = true : nullLocation = false;
    // });
  }

  getLocation() async {
    Map<String, double> location;
    // Platform messages may fail, so we use a try/catch PlatformException.

    try {
      _permission = await _location.hasPermission();
      location = await _location.getLocation();

      error = null;
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        error = 'Permission denied';
      } else if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error =
            'Permission denied - please ask the user to enable it from the app settings';
      }

      location = null;
    }

    setState(() {
      _startLocation = location;
    });
  }

  @override
  Widget build(BuildContext context) {
    //method for popup logged out
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    if (_currentLocation == null) {
      print("Turn on location");
      setState(() {
        nullLocation = true;
      });
    }

    return Scaffold(
      drawer: Drawer(
        child: DrawerPage(),
      ),
      body: Container(
        height: height,
        width: width,
        child: GoogleMap(
          mapType: MapType.hybrid,
          minMaxZoomPreference: MinMaxZoomPreference(18.0, 20.0),
          compassEnabled: true,
          cameraTargetBounds: CameraTargetBounds(LatLngBounds(
              northeast: LatLng(27.708426, 85.326022),
              southwest: LatLng(27.707226, 85.324475))),
          initialCameraPosition: CameraPosition(
            target: LatLng(
              _currentLocation["latitude"],
              _currentLocation["longitude"],
            ),
            tilt: 90,
            // LatLng(27.7078999, 85.3252798),
            zoom: 18.0,
          ),
          myLocationEnabled: true,
          onMapCreated: (GoogleMapController controller) {
            mapController.complete(controller);
          },
        ),
        // GoogleMap(
        //   onMapCreated: (controller) {
        //     setState(() {
        //       mapController = controller;
        //     });
        //     showMarkers();
        //   },
        //   options: GoogleMapOptions(
        //     minMaxZoomPreference: MinMaxZoomPreference(18.0, 20.0),
        //     compassEnabled: true,
        //     trackCameraPosition: true,
        //     cameraTargetBounds: CameraTargetBounds(LatLngBounds(
        //         northeast: LatLng(27.708426, 85.326022),
        //         southwest: LatLng(27.707226, 85.324475))),
        //     mapType: MapType.normal,
        //     cameraPosition: CameraPosition(
        //       target: LatLng(
        //         _currentLocation["latitude"],
        //         _currentLocation["longitude"],
        //       ),
        //       tilt: 90,
        //       // LatLng(27.7078999, 85.3252798),
        //       zoom: 18.0,
        //     ),
        //     myLocationEnabled: true,
        //     // rotateGesturesEnabled: false,
        //     // scrollGesturesEnabled: false,
        //     tiltGesturesEnabled: false,
        //   ),
        // ),
      ),
    );
  }

  // void showMarkers() {
  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.708426, 85.326022),
  //       infoWindowText: InfoWindowText("Nepal Block", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.708289, 85.324736),
  //       infoWindowText: InfoWindowText("Parking", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.708605, 85.325422),
  //       infoWindowText: InfoWindowText("Brit Cafe", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.708375, 85.325382),
  //       infoWindowText: InfoWindowText("Badminton Court", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.707510, 85.325296),
  //       infoWindowText: InfoWindowText("Chiya Chutari", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.707473, 85.325440),
  //       infoWindowText: InfoWindowText(
  //           "Student Service(London Block)", "Islington College"),
  //     ),
  //   );

  //   mapController.addMarker(
  //     MarkerOptions(
  //       position: LatLng(27.707269, 85.325503),
  //       infoWindowText: InfoWindowText("Lecture Building", "Islington College"),
  //     ),
  //   );
  // }
}

//class for popUpMenuOption
// class MenuItemsLoggedOut {
//   static const String signin = "Signin";
//   static const String login = "Login";
//   static const String settings = "Settings";

//   static const List<String> choices = <String>[signin, login, settings];
// }

// class MenuItemsLoggedIn {
//   static const String logout = "Logout";
//   static const String settings = "Settings";

//   static const List<String> choices = <String>[logout, settings];
// }
