import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:islington_navigation_flutter/controller/dynamic_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsPage extends StatefulWidget {
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool darkTheme = false;

  _getBrightness() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      darkTheme = (prefs.getBool("isDark") ?? false) ? true : false;
    });
  }

  _userLogout() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.remove("userid");
    print("User successfully logged out");
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getBrightness();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Settings"),
        ),
        body: ListView(
          children: <Widget>[
            Container(
              color: darkTheme ? Colors.grey : Colors.white,
              child: ListTile(
                title: Text(
                  "Dark Mode",
                ),
                trailing: CupertinoSwitch(
                  activeColor: Colors.black87,
                  value: darkTheme,
                  onChanged: (bool value) {
                    DynamicTheme.of(context).setBrightness(
                        darkTheme ? Brightness.light : Brightness.dark);
                    setState(() {
                      darkTheme = !darkTheme;
                    });
                  },
                ),
              ),
            ),
            FlatButton(
              child: Text("Logout"),
              onPressed: () {
                _userLogout();
              },
            )
          ],
        ));
  }
}
