import 'package:flutter/material.dart';
import 'package:islington_navigation_flutter/view/routines/routine_list.dart';
import 'package:islington_navigation_flutter/view/settings_page.dart';

class DrawerPage extends StatefulWidget {
  _DrawerPageState createState() => _DrawerPageState();
}

class _DrawerPageState extends State<DrawerPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.height * 0.20,
            width: MediaQuery.of(context).size.width,
            color: Colors.grey,
            child: Text("This is drawerPage"),
          ),
          FlatButton(
            child: Text("Routine"),
            onPressed: () {
              Navigator.of(context).push(
                new MaterialPageRoute(
                  builder: (c) {
                    return new RoutineList();
                  },
                ),
              );
            },
          ),
          
          FlatButton(
            child: Text("Settings"),
            onPressed: () {
              Navigator.of(context).push(
                new MaterialPageRoute(
                  builder: (c) {
                    return new SettingsPage();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
