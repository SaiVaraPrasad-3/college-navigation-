// var db_host = "http://100.64.201.162:1234";
var db_host = "http://192.168.0.4:1234";

// users

var URL_USER_SIGNUP = "$db_host/users/signup"; //create user and signup(POST)
var URL_USER_LOGIN = "$db_host/users/login"; //login user (POST)
var URL_USER_USER_ID = "$db_host/users/userprofile"; //get userid (get)

// blocks

var URL_BLOCKS_GET_ALL = "$db_host/blocks/"; //get all blocks
var URL_BLOCKS_GET_INDIVIDUAL = "$db_host/blocks/"; //get individual blocks (:id) gives block id
