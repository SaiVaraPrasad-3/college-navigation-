import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:islington_navigation_flutter/controller/utils/constants.dart';

class Blocks {
  //Data in database are stored in such manner.
  final int block_id;
  final String block_name;
  final double latitude;
  final double longitude;
  final String image;
  final String created_at;
  final String updated_at;

  //Constructor
  Blocks(
      {this.block_id,
      this.block_name,
      this.latitude,
      this.longitude,
      this.image,
      this.created_at,
      this.updated_at});

  //Static method to serialize the json format data of the Blocks
  factory Blocks.fromJson(Map<String, dynamic> json) {
    return Blocks(
      block_id: json["block_id"],
      block_name: json["block_name"],
      latitude: json["latitude"],
      longitude: json["longitude"],
      image: json["image"],
      created_at: json["created_at"],
      updated_at: json["updated_at"],
    );
  }
}

//create Blocks
// Future<String> createUser(http.Client client, Blocks user) async {
//   var createValue = {
//     "user_id": user.user_id,
//     "first_login": user.first_login.toString(),
//     "admin": user.admin.toString(),
//     "name": user.name,
//     "gender": user.gender,
//     "email": user.email,
//     "user_name": user.user_name,
//     "password": user.password,
//   };

//   final response = await client.post(
//     URL_USER_SIGNUP,
//     body: createValue,
//   );

//   if (response.statusCode == 200) {
//     Map<String, dynamic> mapResponse = json.decode(response.body);
//     if (mapResponse["status"] == "200" && mapResponse["error"] == null) {
//       final response = mapResponse["response"].cast<Map<String, dynamic>>();
//       print(response);
//       return "200";
//     } else {
//       print(mapResponse);
//       return "501";
//     }
//   } else {
//     print("User not Created");
//     return "500";
//   }
// }

// Future<List<Blocks>> loginUser(http.Client client, Blocks user) async {
//   var createValue = {
//     "user_name": user.user_name,
//     "password": user.password,
//   };

//   final response = await client.post(
//     URL_USER_LOGIN,
//     body: createValue,
//   );

//   if (response.statusCode == 200) {
//     //Mapping the data on the server from JSON to Map<String, dynamic>
//     Map<String, dynamic> mapResponse = json.decode(response.body);
//     //The data from the server will contain two main attributes 'status' and 'response'
//     //result specifies the status of the data received
//     //data contains the Blocks data
//     //if the status is fine then it contains "200"
//     if (mapResponse["status"] == 200 && mapResponse["error"] == null) {
//       //The Blocks data inside "data" is the casted to <String, dynamic> mapping.
//       final Blocks = mapResponse["response"].cast<Map<String, dynamic>>();
//       //Creating a serialized data from the json
//       final listOfBlocks = await Blocks.map<Blocks>((json) {
//         return Blocks.fromJson(json);
//       }).toList();
//       return listOfBlocks;
//     } else {
//       print(mapResponse);
//       return [];
//     }
//   } else {
//     //Throw exception if the response status code id not 200.
//     throw Exception("Failed to load Blocks.");

//     // print("Failed to load Blocks.");
//   }
// }
// 


Future<List<Blocks>> fetchAllBlocks(http.Client client) async {
  //Get the block url from the constants.dart file inside the utils directory.

  final response = await client.get(
    URL_BLOCKS_GET_ALL,
    headers: {
      "Content-Type": "application/json"
    },
  );
//  print(response);
  //Response if success returns the code 200
  if (response.statusCode == 200) {
    //Mapping the data on the server from JSON to Map<String, dynamic>
    Map<String, dynamic> mapResponse = json.decode(response.body);
    //The data from the server will contain two main attributes 'status' and 'response'
    //result specifies the status of the data received
    //data contains the blocks data
    //if the status is fine then it contains "200"
    if (mapResponse["status"] == 200 && mapResponse["error"] == null) {
      //The block data inside "data" is the casted to <String, dynamic> mapping.
      final users = mapResponse["response"].cast<Map<String, dynamic>>();
      //Creating a serialized data from the json
      final listOfBlocks = await users.map<Blocks>((json) {
        return Blocks.fromJson(json);
      }).toList();
      return listOfBlocks;
    } else {
      print(mapResponse);
      return [];
    }
  } else {
    //Throw exception if the response status code id not 200.
    throw Exception("Failed to load blocks.");
  }
}