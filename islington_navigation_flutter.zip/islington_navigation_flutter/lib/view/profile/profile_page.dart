import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:islington_navigation_flutter/view/credentials/login_page.dart';


class ProfilePage extends StatefulWidget {
  ProfilePage({this.loggedin});
  String loggedin;

  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: widget.loggedin != null
            ? Center(
                child: ListView(
                  children: <Widget>[
                    const Icon(
                      CupertinoIcons.profile_circled,
                      size: 160.0,
                      color: Color(0xFF646464),
                    ),
                    Text("You have successfully loggedin"),
                  ],
                ),
              )
            : NotLoggedIn());
  }
}

class NotLoggedIn extends StatefulWidget {
  @override
  _NotLoggedInState createState() => _NotLoggedInState();
}

class _NotLoggedInState extends State<NotLoggedIn> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const Icon(
            CupertinoIcons.profile_circled,
            size: 160.0,
            color: Color(0xFF646464),
          ),
          CupertinoButton.filled(
              child: Text("Sign in"),
              onPressed: () {
                Navigator.of(context).push(
                  new MaterialPageRoute(
                    builder: (c) {
                      return new LoginPage();
                    },
                  ),
                );
              }),
        ],
      ),
    );
  }
}
