import 'package:flutter/material.dart';

class BlocksDetails extends StatefulWidget {

  BlocksDetails({
    this.block_id,
    this.block_name,
    this.latitude,
    this.longitude,
    this.image
  });

  int block_id;
  String block_name;
  double latitude;
  double longitude;
  String image;

  @override
  _BlocksDetailsState createState() => _BlocksDetailsState();
}

class _BlocksDetailsState extends State<BlocksDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.block_name),
      ),
      body: new Text(widget.block_name),
    );
  }
}