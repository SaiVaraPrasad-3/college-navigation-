import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:islington_navigation_flutter/model/app/blocks.dart';
import 'package:islington_navigation_flutter/view/drawer%20page/drawer.dart';
import 'package:islington_navigation_flutter/view/overview/blocks.dart';

class CollegeOverview extends StatefulWidget {
  static String tag = "profile-page";
  @override
  CollegeOverviewState createState() {
    return new CollegeOverviewState();
  }
}

class CollegeOverviewState extends State<CollegeOverview> {
  @override
  Widget build(BuildContext context) {
    List<Widget> _buildGridTiles(dynamic data) {
      List<Widget> widgets =
          new List<Widget>.generate(data.length, (int index) {
        return Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: BlocksTile(
            block: data[index],
          ),
        );
      });

      return widgets;
    }

    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: new AppBar(
        // iconTheme: Theme.of(context).iconTheme,
        title: new Text(
          "Blocks",
        ),
        centerTitle: true,
        // backgroundColor: Theme.of(context).backgroundColor,
      ),
      drawer: Drawer(
        child: DrawerPage(),
      ),
      body: FutureBuilder(
          future: fetchAllBlocks(http.Client()),
          builder: (context, blocks) {
            if (!blocks.hasError) {
              // print(subscribedTopics.error);
            }
            return blocks.hasData
                // ? TopicsBuilder(subscribedTopics.data)
                ? GridView.count(
                    addRepaintBoundaries: true,
                    padding: EdgeInsets.all(20.0),
                    crossAxisCount: 1,
                    // crossAxisSpacing: 4.0,
                    scrollDirection: Axis.vertical,
                    //mainAxisSpacing: 1.0,
                    children: _buildGridTiles(blocks.data))
                : Center(
                    child: CircularProgressIndicator(),
                  );
          }),
    );
  }
}

class BlocksTile extends StatefulWidget {
  BlocksTile({
    this.block,
  });

  final Blocks block;
//  final DocumentSnapshot documentSnapshot;

  @override
  BlocksTileState createState() {
    return new BlocksTileState();
  }
}

class BlocksTileState extends State<BlocksTile> {
  bool changeSwitchValue = false;
  bool initValue = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Padding(
        padding: const EdgeInsets.all(2.0),
        child: Card(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30.0)),
            elevation: 10.0,
            child: Stack(alignment: Alignment(0.0, 1.0), children: <Widget>[
              Image.asset(
                'assets/pasta.jpg',
                height: double.infinity,
                width: double.infinity,
                fit: BoxFit.fill,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.black,
                ),
                width: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Text(
                    widget.block.block_name,
                    style: TextStyle(
                      fontSize: 21.0,
                      fontWeight: FontWeight.w200,
                    ),
                  ),
                ),
              ),
            ])),
      ),
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return BlocksDetails(
              block_id: widget.block.block_id,
              block_name: widget.block.block_name,
              latitude: widget.block.latitude,
              longitude: widget.block.longitude,
              image: widget.block.image);
        }));
      },
    );
  }
}
