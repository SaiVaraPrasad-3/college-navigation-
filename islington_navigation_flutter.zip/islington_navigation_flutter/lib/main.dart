import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:islington_navigation_flutter/controller/dynamic_theme.dart';
import 'package:islington_navigation_flutter/demo.dart';
import 'package:islington_navigation_flutter/view/credentials/login_page.dart';
import 'package:islington_navigation_flutter/view/credentials/register_page.dart';
import 'package:islington_navigation_flutter/view/map_screen.dart';
import 'package:islington_navigation_flutter/view/overview.dart';
import 'package:islington_navigation_flutter/view/profile/profile_page.dart';
import 'package:islington_navigation_flutter/view/routines/routine_list.dart';
import 'package:islington_navigation_flutter/view/settings_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  Brightness brightness;
  SharedPreferences prefs = await SharedPreferences.getInstance();
  brightness =
      (prefs.getBool("isDark") ?? false) ? Brightness.dark : Brightness.light;
  runApp(new NavigationApp(
    brightness: brightness,
  ));
}

class NavigationApp extends StatelessWidget {
  Brightness brightness;
  NavigationApp({this.brightness});
  @override
  Widget build(BuildContext context) {
    return DynamicTheme(
        defaultBrightness: Brightness.light,
        data: (brightness) => new ThemeData(
              primarySwatch: Colors.red,
              platform: TargetPlatform.iOS,
              brightness: brightness,
            ),
        themedWidgetBuilder: (context, theme) {
          return new MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Virtual Navigation',
            theme: theme,
            home: MainPage(),
            routes: <String, WidgetBuilder> {
              '/overview': (BuildContext context) => CollegeOverview(),
              '/routine': (BuildContext context) => RoutineList(),
              '/profile' : (BuildContext context) => ProfilePage(),
              '/login' : (BuildContext context) => LoginPage(),
              '/register' : (BuildContext context) => RegisterPage(),
              '/setting' : (BuildContext context) => SettingsPage(),
              '/mapscreen' : (BuildContext context) => MapScreen(),
            },
          );
        });
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => new _MainPageState();
}

class _MainPageState extends State<MainPage> {
  PageController _pageController;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _pageController = new PageController();
  }

  @override
  void dispose() {
    super.dispose();
    _pageController.dispose();
  }

  void navigationTapped(int page) {
    // Animating to the page.
    // You can use whatever duration and curve you like
    _pageController.animateToPage(page, 
        duration: const Duration(milliseconds: 300), curve: Curves.ease);
  }

  void onPageChanged(int page) {
    setState(() {
      this._page = page;
    });
  }


    @override
  Widget build(BuildContext context) {
    return WillPopScope(
      
      // Prevent swipe popping of this page. Use explicit exit buttons only.
      onWillPop: () => Future<bool>.value(true),
      child: DefaultTextStyle(
        style: CupertinoTheme.of(context).textTheme.textStyle,
        child: CupertinoTabScaffold(
          tabBar: CupertinoTabBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.home),
                title: Text('College Overview'),
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.profile_circled),
                title: Text('Profile'),
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.location_solid),
                title: Text('Map'),
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.settings),
                title: Text('Settings'),
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.eye),
                title: Text('Demos'),
              ),
            ],
          ),
          tabBuilder: (BuildContext context, int index) {
            assert(index >= 0 && index <= 4);
            switch (index) {
              case 0:
                return CupertinoTabView(
                  builder: (BuildContext context) {
                    return CollegeOverview();
                  },
                );
                break;
              case 1:
                return CupertinoTabView(
                  builder: (BuildContext context) => ProfilePage(),
                );
                break;
              case 2:
                return CupertinoTabView(
                  builder: (BuildContext context) => MapScreen(),
                );
                break;
              case 3:
                return CupertinoTabView(
                  builder: (BuildContext context) => SettingsPage(),
                );
                break;
              case 3:
                return CupertinoTabView(
                  builder: (BuildContext context) => PersistentBottomSheetDemo(),
                );
                break;
            }
            return null;
          },
        ),
      ),
    );
  }
}
